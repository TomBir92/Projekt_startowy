# Umweltaspekte
Wtyczka do QGIS do przygotowywania zestawień na podstawie warstw geoprzestrzennych.
