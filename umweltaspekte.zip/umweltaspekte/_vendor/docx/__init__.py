# original source code changed by rewriting import statements
# encoding: utf-8

from umweltaspekte._vendor.docx.api import Document  # noqa

__version__ = "0.8.11"


# register custom Part classes with opc package reader

from umweltaspekte._vendor.docx.opc.constants import CONTENT_TYPE as CT, RELATIONSHIP_TYPE as RT
from umweltaspekte._vendor.docx.opc.part import PartFactory
from umweltaspekte._vendor.docx.opc.parts.coreprops import CorePropertiesPart

from umweltaspekte._vendor.docx.parts.document import DocumentPart
from umweltaspekte._vendor.docx.parts.hdrftr import FooterPart, HeaderPart
from umweltaspekte._vendor.docx.parts.image import ImagePart
from umweltaspekte._vendor.docx.parts.numbering import NumberingPart
from umweltaspekte._vendor.docx.parts.settings import SettingsPart
from umweltaspekte._vendor.docx.parts.styles import StylesPart


def part_class_selector(content_type, reltype):
    if reltype == RT.IMAGE:
        return ImagePart
    return None


PartFactory.part_class_selector = part_class_selector
PartFactory.part_type_for[CT.OPC_CORE_PROPERTIES] = CorePropertiesPart
PartFactory.part_type_for[CT.WML_DOCUMENT_MAIN] = DocumentPart
PartFactory.part_type_for[CT.WML_FOOTER] = FooterPart
PartFactory.part_type_for[CT.WML_HEADER] = HeaderPart
PartFactory.part_type_for[CT.WML_NUMBERING] = NumberingPart
PartFactory.part_type_for[CT.WML_SETTINGS] = SettingsPart
PartFactory.part_type_for[CT.WML_STYLES] = StylesPart

del (
    CT,
    CorePropertiesPart,
    DocumentPart,
    FooterPart,
    HeaderPart,
    NumberingPart,
    PartFactory,
    SettingsPart,
    StylesPart,
    part_class_selector,
)
