<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="2.0" language="af" sourcelanguage="en">
<context>
    <name>@default</name>
    <message>
        <location filename="test_translations.py" line="48"/>
        <source>Good morning</source>
        <translation>Goeie more</translation>
    </message>
</context>
</TS>
